"""
Inventory Management
Handles stock tracking, capacity checks, and FIFO allocation.
"""

import logging
from typing import Optional, List, Dict, Tuple
from datetime import datetime, timedelta
from database.db_manager import db

logger = logging.getLogger(__name__)


class InventoryManager:
    """Manage godown inventory with capacity checks and FIFO."""
    
    def __init__(self, config: Dict):
        self.config = config
        capacity_config = config.get('capacity', {}) or {}
        self.total_capacity = float(capacity_config.get('total', 100000) or 100000)
        self.crop_capacities = capacity_config.get('per_crop', {}) or {}
        # Repair missing/zero capacity records in an existing database without
        # resetting any stock already recorded for a crop.
        self._ensure_crop_capacity_records()

    def _default_crop_capacities(self) -> Dict[str, float]:
        defaults = {
            'rice': 40000.0,
            'wheat': 30000.0,
            'maize': 15000.0,
            'pulses': 15000.0,
        }
        for crop, capacity in self.crop_capacities.items():
            try:
                value = float(capacity)
                if value > 0:
                    defaults[str(crop).lower()] = value
            except (TypeError, ValueError):
                logger.warning("Ignoring invalid capacity for crop %s: %r", crop, capacity)
        return defaults

    def _ensure_crop_capacity_records(self) -> None:
        """Ensure each supported crop has a positive configured DB capacity."""
        for crop, capacity in self._default_crop_capacities().items():
            row = db.fetchone(
                "SELECT allocated_capacity_kg FROM crop_capacity WHERE LOWER(crop_type) = ?",
                (crop,)
            )
            if row is None:
                db.execute(
                    "INSERT OR IGNORE INTO crop_capacity (crop_type, allocated_capacity_kg, current_stock_kg) VALUES (?, ?, 0)",
                    (crop, capacity)
                )
            else:
                try:
                    stored_capacity = float(row['allocated_capacity_kg'] or 0)
                except (TypeError, ValueError):
                    stored_capacity = 0.0
                if stored_capacity <= 0:
                    db.execute(
                        "UPDATE crop_capacity SET allocated_capacity_kg = ? WHERE LOWER(crop_type) = ?",
                        (capacity, crop)
                    )

    def _get_crop_capacity(self, crop_type: str) -> float:
        """Read crop capacity from the database first, then configuration.

        The database is seeded with allocated capacities for each crop. Using
        only config['capacity']['per_crop'] made every crop's capacity zero
        when settings.yaml did not define that optional section.
        """
        row = db.fetchone(
            "SELECT allocated_capacity_kg FROM crop_capacity WHERE crop_type = ?",
            (crop_type,)
        )
        if row and row['allocated_capacity_kg'] is not None:
            try:
                stored_capacity = float(row['allocated_capacity_kg'])
            except (TypeError, ValueError):
                stored_capacity = 0.0
            if stored_capacity > 0:
                return stored_capacity

        configured = self.crop_capacities.get(crop_type)
        if configured is not None:
            try:
                configured_capacity = float(configured)
                if configured_capacity > 0:
                    return configured_capacity
            except (TypeError, ValueError):
                logger.warning("Invalid configured capacity for crop %s: %r", crop_type, configured)

        # Keep sensible defaults for a fresh or partially migrated database.
        return self._default_crop_capacities().get(crop_type.lower(), 0.0)
    
    def check_capacity(self, crop_type: str, weight_kg: float) -> Tuple[bool, str]:
        """
        Check if adding weight is within capacity.
        Returns (ok: bool, message: str)
        """
        # Check total capacity
        total_stock = self.get_total_stock()
        if total_stock + weight_kg > self.total_capacity:
            return False, f"Total capacity exceeded. Available: {self.total_capacity - total_stock:.2f} kg"
        
        # Check crop-specific capacity
        crop_capacity = self._get_crop_capacity(crop_type)
        crop_stock = float(db.get_crop_stock(crop_type) or 0.0)
        crop_available = max(0.0, crop_capacity - crop_stock)

        if crop_capacity <= 0:
            return False, f"No capacity is configured for {crop_type.title()}. Please check crop_capacity in the database."

        if crop_stock + weight_kg > crop_capacity:
            return False, f"{crop_type.title()} capacity exceeded. Available: {crop_available:.2f} kg"
        
        return True, "Capacity OK"
    
    def get_total_stock(self) -> float:
        """Get total current stock across all crops."""
        row = db.fetchone(
            "SELECT SUM(current_stock_kg) as total FROM crop_capacity"
        )
        return row['total'] if row and row['total'] else 0.0
    
    def get_crop_stock(self, crop_type: str) -> float:
        """Get current stock for a crop."""
        return db.get_crop_stock(crop_type)
    
    def get_stock_summary(self) -> List[Dict]:
        """Get stock summary for all crops."""
        rows = db.fetchall(
            """
            SELECT 
                crop_type,
                allocated_capacity_kg,
                current_stock_kg,
                (allocated_capacity_kg - current_stock_kg) as available_kg,
                ROUND((current_stock_kg * 100.0 / allocated_capacity_kg), 2) as utilization_percent
            FROM crop_capacity
            ORDER BY crop_type
            """
        )
        return [dict(row) for row in rows]
    
    def allocate_stack(self, crop_type: str, weight_kg: float) -> Optional[str]:
        """
        Allocate a stack location for storage.
        Returns stack_location code or None if full.
        """
        row = db.fetchone(
            """
            SELECT location_code, capacity_kg, current_weight_kg
            FROM stack_locations
            WHERE crop_type = ? AND status = 'available'
              AND (capacity_kg - current_weight_kg) >= ?
            ORDER BY current_weight_kg ASC
            LIMIT 1
            """,
            (crop_type, weight_kg)
        )
        
        if not row:
            logger.warning(f"No available stack for {crop_type}, {weight_kg} kg")
            return None
        
        return row['location_code']
    
    def update_stack_weight(self, location_code: str, delta_kg: float):
        """Update stack weight (positive = add, negative = remove)."""
        db.execute(
            """
            UPDATE stack_locations
            SET current_weight_kg = current_weight_kg + ?,
                status = CASE 
                    WHEN (current_weight_kg + ?) >= capacity_kg THEN 'full'
                    ELSE 'available'
                END
            WHERE location_code = ?
            """,
            (delta_kg, delta_kg, location_code)
        )
    
    def find_batches_for_withdrawal(self, crop_type: str, required_kg: float,
                                    farmer_id: Optional[int] = None) -> List[Dict]:
        """
        Find batches for withdrawal/selling using FIFO + expiry priority.
        If farmer_id given, only return that farmer's batches.
        """
        query = """
        SELECT *
        FROM batches
        WHERE crop_type = ? AND status = 'stored'
        """
        params = [crop_type]
        
        if farmer_id:
            query += " AND farmer_id = ?"
            params.append(farmer_id)
        
        query += " ORDER BY expiry_date ASC, storage_date ASC"
        
        rows = db.fetchall(query, tuple(params))
        batches = [dict(row) for row in rows]
        
        # Select batches until we have enough weight
        selected = []
        total_weight = 0.0
        
        for batch in batches:
            selected.append(batch)
            total_weight += batch['weight_kg']
            if total_weight >= required_kg:
                break
        
        return selected
    
    def get_expiring_batches(self, days_threshold: int = 7) -> List[Dict]:
        """Get batches expiring within threshold days."""
        threshold_date = (datetime.now() + timedelta(days=days_threshold)).date()
        
        rows = db.fetchall(
            """
            SELECT b.*, f.name as farmer_name, f.phone as farmer_phone
            FROM batches b
            JOIN farmers f ON b.farmer_id = f.id
            WHERE b.status = 'stored' AND b.expiry_date <= ?
            ORDER BY b.expiry_date ASC
            """,
            (threshold_date.isoformat(),)
        )
        
        return [dict(row) for row in rows]
    
    def confiscate_expired(self) -> int:
        """
        Confiscate all expired batches.
        Returns number of batches confiscated.
        """
        today = datetime.now().date()
        
        expired = db.fetchall(
            """
            SELECT id, weight_kg, crop_type, stack_location
            FROM batches
            WHERE status = 'stored' AND expiry_date < ?
            """,
            (today.isoformat(),)
        )
        
        count = 0
        for batch in expired:
            db.update(
                'batches',
                {
                    'status': 'confiscated',
                    'confiscation_reason': 'Expired',
                    'confiscation_date': today.isoformat()
                },
                'id = ?',
                (batch['id'],)
            )
            
            # Update stock
            db.update_crop_stock(batch['crop_type'], -batch['weight_kg'])
            
            # Update stack
            if batch['stack_location']:
                self.update_stack_weight(batch['stack_location'], -batch['weight_kg'])
            
            count += 1
        
        logger.info(f"Confiscated {count} expired batches")
        return count